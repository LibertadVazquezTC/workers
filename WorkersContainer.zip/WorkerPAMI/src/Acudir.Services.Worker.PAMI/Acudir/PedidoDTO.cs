﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Worker.PAMI.Domain.Acudir
{
    public class DestinoDemora
    {
        public int Dias { get; set; }
        public int Horas { get; set; }
        public int Minutos { get; set; }
    }
    public class Direccion
    {
        public DireccionLocalidad? DireccionLocalidad { get; set; }
        public int DireccionId { get; set; }
        public string? Domicilio { get; set; }
        public int Piso { get; set; }
        public string? Depto { get; set; }
        public string? CalleAdyacente1 { get; set; }
        public string? CalleAdyacente2 { get; set; }
        public int? DireccionLocalidadId { get; set; }
        public string? Zona { get; set; }
        public double Latitud { get; set; }
        public double Longitud { get; set; }
        public bool Borrado { get; set; }
        public string? AuditoriaInsertUser { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public object? AuditoriaUpdateUser { get; set; }
        public object? AuditoriaUpdateDate { get; set; }
    }
    public class DireccionCordon
    {
        public int DireccionCordonId { get; set; }
        public string? Descripcion { get; set; }
        public bool Activo { get; set; }
        public string? AuditoriaInsertUser { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public object? AuditoriaUpdateUser { get; set; }
        public object? AuditoriaUpdateDate { get; set; }
    }
    public class DireccionLocalidad
    {
        public DireccionCordon? DireccionCordon { get; set; }
        public DireccionPartido? DireccionPartido { get; set; }
        public DireccionZonaGeografica? DireccionZonaGeografica { get; set; }
        public int DireccionLocalidadId { get; set; }
        public string? Descripcion { get; set; }
        public int Kilometros { get; set; }
        public int DireccionPartidoId { get; set; }
        public int DireccionZonaGeograficaId { get; set; }
        public double Latitud { get; set; }
        public double Longitud { get; set; }
        public bool Borrado { get; set; }
        public int? ZonaVersionDetalleId { get; set; }
        public int DireccionCordonId { get; set; }
        public string? AuditoriaInsertUser { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public object? AuditoriaUpdateUser { get; set; }
        public object? AuditoriaUpdateDate { get; set; }
    }
    public class DireccionPartido
    {
        public DireccionProvincia? DireccionProvincia { get; set; }
        public int DireccionPartidoId { get; set; }
        public string? Descripcion { get; set; }
        public int DireccionProvinciaId { get; set; }
        public bool Borrado { get; set; }
        public string? AuditoriaInsertUser { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public object? AuditoriaUpdateUser { get; set; }
        public object? AuditoriaUpdateDate { get; set; }
    }
    public class DireccionProvincia
    {
        public int DireccionProvinciaId { get; set; }
        public string? Descripcion { get; set; }
        public string? Jurisdiccion { get; set; }
        public bool Borrado { get; set; }
        public int CapitalDireccionLocalidadId { get; set; }
        public string? AuditoriaInsertUser { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public object? AuditoriaUpdateUser { get; set; }
        public object? AuditoriaUpdateDate { get; set; }
    }
    public class DireccionZonaGeografica
    {
        public int DireccionZonaGeograficaId { get; set; }
        public string? Descripcion { get; set; }
        public bool Borrado { get; set; }
        public object? TextColor { get; set; }
        public object? BackGroundColor { get; set; }
        public string? AuditoriaInsertUser { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public object? AuditoriaUpdateUser { get; set; }
        public object? AuditoriaUpdateDate { get; set; }
    }
    public class OrigenDemora
    {
        public int? Dias { get; set; }
        public int? Horas { get; set; }
        public int? Minutos { get; set; }
    }
    public class PedidoCompletoAdicional
    {
        public int? PedidoAdicionalTipoId { get; set; }
        public string? Descripcion { get; set; }
        public int? Cantidad { get; set; }
    }
    public class PedidoCompletoComentario
    {
        public string? Descripcion { get; set; }
        public string? Usuario { get; set; }
        public DateTime Hora { get; set; }
    }
    public class PedidoCompletoDerivacion
    {
        public int DerivacionId { get; set; }
        public string? DomicilioDesde { get; set; }
        public string? Diagnostico { get; set; }
        public string? Comentario { get; set; }
        public string? Complejidad { get; set; }
        public string? DestinoPreferencia { get; set; }
        public string? TomadorInterno { get; set; }
        public string? TomadorExterno { get; set; }
        public DateTime HoraSolicitud { get; set; }
        public int? Estado { get; set; }
        public string? DerivadorInterno { get; set; }
        public string? DerivadorExterno { get; set; }
        public string? Medico { get; set; }
        public DateTime? HoraDerivacion { get; set; }
    }
    public class PedidoCompletoDiagnostico
    {
        public string? Descripcion { get; set; }
        public string? Comentario { get; set; }
        public DateTime Hora { get; set; }
        public string? Usuario { get; set; }
    }
    public class PedidoCompletoTramo
    {
        public DateTime? DesdeTeorico { get; set; }
        public DateTime? HastaTeorico { get; set; }
        public DateTime? HorarioDespacho { get; set; }
        public int? TramoNro { get; set; }
        public int? PedidoTramoId { get; set; }
        public List<PedidoCompletoTramoUMovilHorario>? PedidoCompletoTramoUMovilHorario { get; set; }
        public List<PedidoCompletoTramoDetalle>? PedidoCompletoTramoDetalle { get; set; }
    }
    public class PedidoCompletoTramoDetalle
    {
        public Direccion? Direccion { get; set; }
        public DateTime? HorarioProgramado { get; set; }
        public DateTime? HorarioTeorico { get; set; }
        public int? OrigenDestino { get; set; }
        public int? PedidoTramoDetalleId { get; set; }
    }
    public class PedidoCompletoTramoEquipo
    {
        public string? Descripcion { get; set; }
        public string? ComponenteDescripcion { get; set; }
    }
    public class PedidoCompletoTramoUMovilHorario
    {
        public string? Descripcion { get; set; }
        public string? Proveedor { get; set; }
        public bool? Apoyo { get; set; }
        public int? UMovilId { get; set; }
        public DateTime? OrigenArribo { get; set; }
        public DateTime? OrigenPartida { get; set; }
        public OrigenDemora? OrigenDemora { get; set; }
        public DestinoDemora? DestinoDemora { get; set; }
        public DateTime? DestinoArribo { get; set; }
        public DateTime? DestinoPartida { get; set; }
        public List<PedidoCompletoTramoEquipo>? PedidoCompletoTramoEquipo { get; set; }
    }
    public class PedidoDTO
    {
        //TODO: completar con los datos que se necesitan
        public int PedidoId { get; set; }
        public string? QuienLlama { get; set; }
        public DateTime Fecha { get; set; }
        public string? Tomador { get; set; }
        public DateTime HoraToma { get; set; }
        public int? Apoyo { get; set; }
        public string? Sintoma { get; set; }
        public string? ObraSocial { get; set; }
        public string? ZonaDesde { get; set; }
        public string? TPSexoEdad { get; set; }
        public string? NombreAfiliado { get; set; }
        public string? Plan { get; set; }
        public object? ZonaHasta { get; set; }
        public int? Coseguro { get; set; }
        public string? NroAfiliado { get; set; }
        public string? NroIncidente { get; set; }
        public string? Telefono { get; set; }
        public string? TelefonoPadron { get; set; }
        public string? DniPadron { get; set; }
        public object? ObsAfiliado { get; set; }
        public string? ObsDom { get; set; }
        public int EstadoId { get; set; }
        public string? TipoPrestacion { get; set; }
        public string? Estado { get; set; }
        public object? EventoDetalleLocacionId { get; set; }
        public bool PacientePsiquiatrico { get; set; }
        public bool PacienteRecomendado { get; set; }
        public bool PMI { get; set; }
        public bool Discapacidad { get; set; }
        public List<PedidoCompletoTramo>? PedidoCompletoTramo { get; set; }
        public List<PedidoCompletoDerivacion>? PedidoCompletoDerivacion { get; set; }
        public List<PedidoCompletoAdicional>? PedidoCompletoAdicional { get; set; }
        public List<PedidoCompletoDiagnostico>? PedidoCompletoDiagnostico { get; set; }
        public List<PedidoCompletoComentario>? PedidoCompletoComentario { get; set; }
        public object? PedidoCompletoReclamo { get; set; }
        public object? PedidoCoseguro { get; set; }

    }
}
