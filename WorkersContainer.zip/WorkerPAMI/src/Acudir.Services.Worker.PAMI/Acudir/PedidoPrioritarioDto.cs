﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Workers.PAMI.Domain.Acudir
{
    public class PedidoPrioritarioDto
    {
        public int PedidoId { get; set; }
        public string NroIncidente { get; set; }
        public DateTime Fecha { get; set; }
        public string TipoPrestacion { get; set; }
    }
}
