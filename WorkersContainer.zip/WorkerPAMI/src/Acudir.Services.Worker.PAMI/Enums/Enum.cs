﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Worker.PAMI.Domain.Enums
{
    public enum EstadosEnum
    {
        [Display(Name = "Informado", Description = "Informado al recurso")]
        InformadoAlRecurso = 1,
        [Display(Name = "Despachado", Description = "Despachado")]
        Despachado = 2,
        [Display(Name = "RumboAIncidente", Description = "Rumbo a incidente")]
        RumboAIncidente = 3,
        [Display(Name = "EnIncidente", Description = "En incidente")]
        EnIncidente = 4,
        [Display(Name = "EnEsperaDerivacion", Description = "En espera de derivación")]
        EnEsperaDeDerivacion = 5,
        [Display(Name = "RumboALugarDeDeriv", Description = "Rumbo a lugar de derivación")]
        RumboALugarDeDeriv = 6,
        [Display(Name = "EnLugarDeDeriv", Description = "En lugar de derivación")]
        EnLugarDeDeriv = 7,
        [Display(Name = "RumboABase", Description = "Rumbo a base/Deja al paciente")]
        RumboABase = 8,
        [Display(Name = "Disponible", Description = "Disponible")]
        Disponible = 9,
    }
    public static class EnumerationExtension
    {
        public static TAttribute GetAttribute<TAttribute>(this Enum enumValue)
                    where TAttribute : Attribute
        {
            return enumValue.GetType()
                            .GetMember(enumValue.ToString())
                            .First()
                            .GetCustomAttribute<TAttribute>()!;
        }
    }
}
