﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Worker.PAMI.Domain.Entities
{
    public class Contadores
    {
        public int EnCurso { get; set; }
        public int Anulados { get; set; }
        public int Archivados { get; set; }
        public int Finalizados { get; set; }
        public int ConError { get; set; }
    }
}
