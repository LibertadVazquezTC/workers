﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Worker.PAMI.Domain.Entities
{
    public class IncidentePami
    {
        public int IncidentePamiId { get; set; }
        public int? IncidenteAcudir { get; set; }
        public string JsonNotificacionPami { get; set; }
        public string NroIncidentePami { get; set; }
        public string JsonIncidentePami { get; set; }
        public string JsonReiteracionIncidentePami { get; set; }
        public string JsonCierreIncidentePami { get; set; }
        public string JsonHorariosPami { get; set; }
        public DateTime? FechaRecibido { get; set; }
        public DateTime? FechaCreado { get; set; }
        public DateTime? FechaConfirmado { get; set; }
        public DateTime? FechaDespachado { get; set; }
        public DateTime? FechaInicioViaje { get; set; }
        public DateTime? FechaEnIncidente { get; set; }
        public DateTime? FechaEnEsperaDerivacion { get; set; }
        public DateTime? FechaRumboLugarDerivacion { get; set; }
        public DateTime? FechaEnLugarDerivacion { get; set; }
        public DateTime? FechaRumboBase { get; set; }
        public DateTime? FechaFinalizacion { get; set; }
        public DateTime? FechaAnulacion { get; set; }
        public DateTime? FechaError { get; set; }
        public DateTime? FechaReiteracion { get; set; }
        public DateTime? FechaCierre { get; set; }
        public string MensajeError { get; set; }
    }
}
