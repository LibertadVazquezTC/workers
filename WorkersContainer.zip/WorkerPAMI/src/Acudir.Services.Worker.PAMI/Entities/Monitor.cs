﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Worker.PAMI.Domain.Entities
{
    public class Monitor
    {
        public int? IncidenteAcudir { get; set; }

        [MaxLength(20)]
        public string NroIncidentePami { get; set; }
        public DateTime? FechaRecibido { get; set; }
        public string Clasificacion { get; set; }
        public string Direccion { get; set; }
        //public IEnumerable<AssignmentStatesDTO> Horarios { get; set; }
        public string Horarios { get; set; }
        public string MensajeError { get; set; }
    }
}
