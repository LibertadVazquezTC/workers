﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Worker.PAMI.Domain.Pami
{
    public class GetByIdDTO
    {
        public DateTime timeRequested { get; set; }
        public string responseAgent { get; set; }
        public string classification { get; set; }
        public string responseAgentClass { get; set; }
        public AddressDTO address { get; set; }
        public string phoneNumber { get; set; }
        public string customerName { get; set; }
        public string beneficiaryID { get; set; }
        public string beneficiaryName { get; set; }
        public string gender { get; set; }
        public int? age { get; set; }
        public string ageUnit { get; set; }
        public string originComments { get; set; }
        public string assignmentComments { get; set; }
        public IEnumerable<TriageDTO> triage { get; set; }
        public IEnumerable<AssignmentStatesDTO> assignmentStates { get; set; }
        public IEnumerable<AttributesDTO> attributes { get; set; }
        public string diagnosticCode { get; set; }
        public string diagnosticDescripcion { get; set; }
        public string urgencyDegreeCode { get; set; }
        public string urgencyDegreeDescripcion { get; set; }
        public string finalDestinationCode { get; set; }
        public string finalDestinationDescripcion { get; set; }
        public string healthcareCenter { get; set; }
        public bool isSuccess { get; set; }
        public string message { get; set; }
    }

    public class AttributesDTO
    {
        public int order { get; set; }
        public string name { get; set; }
        public string value { get; set; }
    }

    public class AssignmentStatesDTO
    {
        public int order { get; set; }
        public string description { get; set; }
        public DateTime? timeReported { get; set; }
    }

    public class TriageDTO
    {
        public int order { get; set; }
        public string reason { get; set; }
    }

    public class AddressDTO
    {
        public string streetName { get; set; }
        public string houseNumber { get; set; }
        public string betweenStreet1 { get; set; }
        public string betweenStreet2 { get; set; }
        public string floorApt { get; set; }
        public string additionalData { get; set; }
        public string province { get; set; }
        public string deppartment { get; set; }
        public string city { get; set; }
        public string neighborhood { get; set; }
        public LatLngDTO latLng { get; set; }
        public string pointOfReference { get; set; }
    }

    public class LatLngDTO
    {
        public double latitude { get; set; }
        public double longitude { get; set; }
    }
}
