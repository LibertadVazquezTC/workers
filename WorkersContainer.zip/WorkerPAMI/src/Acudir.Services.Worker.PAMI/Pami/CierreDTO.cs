﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Worker.PAMI.Domain.Pami
{
    public class CierreDTO
    {
        public int PedidoTipoCierreId { get; set; }
        public int DiagnosticoId { get; set; }
        public int SanatorioId { get; set; }
        public string DiagnosticCode { get; set; }
        public string UrgencyDegreeCode { get; set; }
        public string HeathcareCenter { get; set; }
        public string FinalDestinationCode { get; set; }
    }
}
