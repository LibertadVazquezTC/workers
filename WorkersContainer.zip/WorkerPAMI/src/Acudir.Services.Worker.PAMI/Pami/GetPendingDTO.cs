﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Worker.PAMI.Domain.Pami
{
    public class GetPendingDTO
    {
        public IEnumerable<NotificationDTO> notifications { get; set; }
        public DateTime timeRequested { get; set; }
        public bool isSuccess { get; set; }
        public string message { get; set; }
    }

    public class NotificationDTO
    {
        public string notificationType { get; set; }
        public DateTime timeSent { get; set; }
        public string serviceID { get; set; }
        public int order { get; set; }
        public string clasification { get; set; }
    }
}
