﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Worker.PAMI.Domain.Pami
{
    public class RechazarRequest
    {
        public string NumeroIncidente { get; set; }
        public string Zona { get; set; }
    }
}
