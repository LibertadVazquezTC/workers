﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Worker.PAMI.Domain.Pami
{
    public class AuthenticationPami
    {
        public string Grant_type { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public AuthenticationPami()
        { }

        public AuthenticationPami(string grant_type, string username, string password)
        {
            this.Grant_type = grant_type;
            this.Username = username;
            this.Password = password;
        }

        public AuthenticationPami(string username, string password)
        {
            this.Username = username;
            this.Password = password;
            this.Grant_type = "password";
        }
    }
}
