﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Worker.PAMI.Domain.Pami
{
    public class GetOngoingDTO
    {
        public IEnumerable<SummaryDTO> summary { get; set; }
        public DateTime timeRequested { get; set; }
        public bool isSuccess { get; set; }
        public string message { get; set; }
    }
    public class SummaryDTO
    {
        public string id { get; set; }
        public string responseAgent { get; set; }
        public DateTime timeAssigned { get; set; }
        public string classification { get; set; }
    }
}
