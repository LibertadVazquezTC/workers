﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Worker.PAMI.Domain.Pami
{
    public class IngresarReiteracionDto
    {
        public string? JsonReiteracionIncidentePami { get; set; }
    }
}
