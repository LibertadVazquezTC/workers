﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Worker.PAMI.Domain.Pami
{
    public class IngresarErrorDto
    {
        public int NroIncidente { get; set; }
        public string Message { get; set; }
    }
}
