﻿using Acudir.Services.Worker.PAMI.Domain.Entities;
using Acudir.Services.Worker.PAMI.Domain.Pami;
using Acudir.Services.Workers.PAMI.Services.Dtos;
using Microsoft.AspNetCore.Mvc;
using Refit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Acudir.Services.Workers.PAMI.Services.Interfaces
{
    public interface ILogApiRestService
    {
        [Get("/api/IncidentesPami/ObtenerIncidente/{incidenteId}")]
        Task<ApiResponse<IncidentePami>> ObtenerIncidente(string incidenteId);

        [Post("/api/IncidentesPami/CrearLog/{incidenteId}")]
        Task<int> CrearLog(string incidenteId, [Body] CrearLogDto crearLogDto);

        [Post("/api/IncidentesPami/IngresarFechaCreacion/{nroIncidente}")]
        Task IngresarFechaCreacion(int nroIncidente, int incidenteAcudir);

        [Post("/api/IncidentesPami/IngresarFechaConfirmacion/{nroIncidente}")]
        Task IngresarFechaConfirmacion(int nroIncidente);

        [Post("/api/IncidentesPami/IngresarError")]
        Task IngresarError([Body] IngresarErrorDto ingresarErrorDto);

        [Post("/api/IncidentesPami/IngresarAnulacion")]
        Task IngresarAnulacion(int nroIncidente);

        [Put("/api/IncidentesPami/ActualizarJsonIncidentePami/{nroIncidente}")]
        Task ActualizarJsonIncidentePami(int nroIncidente, [Body] ActualizarJsonIncidentePamiDto actualizarJsonIncidentePamiDto);

        [Put("/api/IncidentesPami/ActualizarJsonHorariosPami/{nroIncidente}")]
        Task ActualizarJsonHorariosPami(int nroIncidente, [Body] ActualizarJsonHorariosPamiDto actualizarJsonHorariosPamiDto);

        [Post("/api/IncidentesPami/IngresarReiteracion/{nroIncidente}")]
        Task IngresarReiteracion(int nroIncidente, [Body] IngresarReiteracionDto ingresarReiteracionDto);

        [Post("/api/IncidentesPami/IngresarFecha/{nroIncidente}")]
        Task IngresarFecha(int nroIncidente, [Body] IngresarFechaDto ingresarFechaDto);

        [Post("/api/IncidentesPami/IngresarCierre/{nroIncidente}")]
        Task IngresarCierre(int nroIncidente, [Body] IngresarCierreDto ingresarCierreDto);
        [Get("/api/IncidentesPami/ObtenerTiempoDeVida/{descripcion}")]
        Task<ApiResponse<JsonElement>> ObtenerTiempoDeVida(string descripcion);
        [Post("/api/IncidentesPami/IngresarTiempoDeVida")]
        Task IngresarTiempoDeVida([Body]TiempoDeVidaDto tiempoDeVidaDto);
        [Put("/api/IncidentesPami/ActualizarTiempoDeVida")]
        Task ActualizarTiempoDeVida([Body]TiempoDeVidaDto tiempoDeVidaDto);
        [Get("/api/IncidentesPami/ValidarSiInformoArribo/{incidenteId}")]
        Task<bool> ValidarSiInformoArribo(string incidenteId);

    }
}
