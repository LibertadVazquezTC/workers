﻿using Acudir.Services.Worker.PAMI.Domain.Acudir;
using Acudir.Services.Worker.PAMI.Domain.Entities;
using Acudir.Services.Worker.PAMI.Domain.Pami;
using Microsoft.AspNetCore.Mvc;
using Refit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Acudir.Services.Workers.PAMI.Services.Interfaces
{
    public interface IPAMIApiRestService
    {
        #region PAMI

        [Get("/api/v1/APIPAMI/Pami/Incidentes/{numeroIncidence}")]
        Task<GetByIdDTO> GetIncidenteById(string numeroIncidence);

        [Get("/api/v1/APIPAMI/Pami/Incidentes/Pendientes")]
        Task<GetPendingDTO> GetIncidentesPendientes();

        [Get("/api/v1/APIPAMI/Pami/Incidentes/EnCurso")]
        Task<GetOngoingDTO> ObtenerIncidentesEnCurso();

        [Put("/api/v1/APIPAMI/Pami/Incidentes/Estados")]
        Task<ResponseDTO> IngresarIncidenteEstado(string numeroIncidence, string estado);

        [Get("/api/v1/APIPAMI/Pami/Incidentes/Destino")]
        Task<IEnumerable<FinalDestinationDTO>> ObtenerDestinosFinales();

        [Get("/api/v1/APIPAMI/Pami/Incidentes/Estados")]
        Task<IEnumerable<AssignmentStatesResponse>> ObtenerEstados();

        [Post("/api/v1/APIPAMI/Pami/Incidentes/Derivar")]
        Task<ResponseDTO> Derivar(string numeroIncidente);

        [Post("/api/v1/APIPAMI/Pami/Incidentes/Rederivar")]
        Task<ResponseDTO> Rederivar(string numeroIncidente, string urgencia);

        [Put("/api/v1/APIPAMI/Pami/Incidentes/Destino")]
        Task<ResponseDTO> IngresarIncidenteDestinoFinal(string numeroIncidence, string destinoFinal);

        [Put("/api/v1/APIPAMI/Pami/Incidentes/GradoUrgencia")]
        Task<ResponseDTO> IngresarIncidenteDiagnosticoGradoUrgencia(string numeroIncidence, string codigoDiagnostico, string codigoGradoUrgencia);

        [Put("/api/v1/APIPAMI/Pami/Incidentes/Sanatorio")]
        Task<ResponseDTO> IngresarIncidenteCentroSalud(string numeroIncidence, string sanatorio);

        [Put("/api/v1/APIPAMI/Pami/Incidentes/Finalizar")]
        Task<ResponseDTO> Finalizar(string numeroIncidence);

        [Put("/api/v1/APIPAMI/Pami/Notificaciones/Reconocer")]
        Task<ResponseDTO> Reconocer([FromBody] NotificationDTO notificacion);

        [Post("/api/v1/APIPAMI/Pami/Incidentes/Rechazar")]
        Task<ResponseDTO> Rechazar([FromBody] RechazarRequest request);

        #endregion

        #region ACUDIR

        [Get("/api/v1/APIPAMI/Acudir/Estado")]
        Task<string> ObtenerEstado(int pedidoId, string mensaje);

        [Get("/api/v1/APIPAMI/Acudir/DestinoFinal")]
        Task<string> ObtenerDestinoFinal(int pedidoTipoCierreId);

        [Get("/api/v1/APIPAMI/Acudir/GradoUrgencia")]
        Task<string> ObtenerGradoUrgencia(int pedidoTipoCierreId);

        [Get("/api/v1/APIPAMI/Acudir/Diagnostico")]
        Task<string> ObtenerDiagnostico(int diagnosticoId);

        [Get("/api/v1/APIPAMI/Acudir/Sanatorio")]
        Task<string> ObtenerSanatorio(int sanatorioId);

        [Post("/api/v1/APIPAMI/Acudir/Convertir")]
        Task<int> ConvertirEnAcudir(GetByIdDTO pamiDataSet, string servicioId);

        [Put("/api/v1/APIPAMI/Acudir/Anulacion/EnviarSolicitud")]
        Task<bool> EnviarSolicitudDeAnulacion(int incidenteACUDIR);

        [Post("/api/v1/APIPAMI/Acudir/Reclamo/Ingresar")]
        Task<bool> IngresarReclamo(int pedidoId, string reclamo);

        [Get("/api/v1/APIPAMI/Acudir/Pedido/{numeroIncidente}")]
        Task<ActionResult<PedidoDTO>> ObtenerPedido(string numeroIncidente);

        [Get("/api/v1/APIPAMI/Acudir/PedidoPrioritario")]
        Task<ApiResponse<JsonElement>> ObtenerPedidoPrioritario();

        [Get("/api/v1/APIPAMI/Acudir/ValidarSiPedidoPamiArribo/{pedidoId}")]
        Task<ApiResponse<bool>> ValidarSiPedidoPamiArribo(int pedidoId);

        [Get("/api/v1/APIPAMI/Acudir/RumboALugarDeDerivacion")]
        Task<ApiResponse<bool>> RumboALugarDeDerivacion(string numeroIncidente);

        [Get("/api/v1/APIPAMI/Acudir/ObtenerPedidoPendieneteAInformar")]
        Task<ApiResponse<JsonElement>> ObtenerPedidoPamiPendienteInformar(string estado);

        #endregion

        #region MAIL SENDER

        [Post("/api/v1/APIPAMI/MailSender/ErrorAlCrear")]
        Task<ResponseDTO> NotificarErrorAlCrear(string incidentePami, string mensaje);

        [Post("/api/v1/APIPAMI/MailSender/ErrorAlAnular")]
        Task<ResponseDTO> NotificarErrorAlAnular(string incidentePami, string mensaje);

        [Post("/api/v1/APIPAMI/MailSender/ErrorAlReclamar")]
        Task<ResponseDTO> NotificarErrorAlReclamar(string incidentePami, string mensaje);

        [Post("/api/v1/APIPAMI/MailSender/ErrorAlReiterar")]
        Task<ResponseDTO> NotificarErrorAlReiterar(string incidentePami, string mensaje);

        [Post("/api/v1/APIPAMI/MailSender/Reiteracion")]
        Task<ResponseDTO> NotificarReiteracion(IncidentePami incidente);

        [Post("/api/v1/APIPAMI/MailSender/ErrorASistemas")]
        Task<ResponseDTO> NotificarErrorASistemas(string mensaje);

        [Post("/api/v1/APIPAMI/MailSender/RechazoIncidente")]
        Task<ResponseDTO> NotificarRechazoIncidente(string incidentePami);

        #endregion
    }
}
