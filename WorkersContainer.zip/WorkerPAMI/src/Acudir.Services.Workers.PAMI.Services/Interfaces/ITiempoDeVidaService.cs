﻿using Acudir.Services.Worker.PAMI.Domain.Pami;
using Acudir.Services.Workers.PAMI.Services.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Workers.PAMI.Services.Interfaces
{
    public interface ITiempoDeVidaService
    {
        Task<bool> IngresarTiempoDeVida();
    }
}
