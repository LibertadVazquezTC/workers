﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Workers.PAMI.Services.Dtos
{
    public class TiempoDeVidaResponseDto
    {
        public bool Success { get; set; }
        public TiempoDeVidaDto? tiempoDeVidaDto { get; set; }
    }
}
