﻿using Acudir.Services.Worker.PAMI.Domain.Pami;
using Acudir.Services.Workers.PAMI.Services.Dtos;
using Acudir.Services.Workers.PAMI.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Refit;
using Newtonsoft.Json;
using System.Net;

namespace Acudir.Services.Workers.PAMI.Services
{
    public class TiempoDeVidaService : ITiempoDeVidaService
    {
        #region Private Fields

        private readonly string _enviroment;
        private readonly ILogApiRestService _iApiLogService;
        private readonly string apiLoggerUrl;
        private readonly string environmentValue;

        #endregion

        public TiempoDeVidaService(EnvironmentSettings settings)
        {
            _enviroment = settings?.Environment ?? throw new ArgumentException("No se encontro valor ingresado para la variable de entorno");
            apiLoggerUrl = settings?.ApiLoggerUrl ?? throw new Exception("No se encontro valor para la url ApiLogger");
            this._iApiLogService = RestService.For<ILogApiRestService>(apiLoggerUrl);
            environmentValue = settings?.Environment ?? "development";
        }

        public async Task<bool> IngresarTiempoDeVida()
        {
            try
            {
                string descripcion = $"acudir.services.workers.pami-{environmentValue.ToLower()}";
                var tiempoDeVidaExistente = await _iApiLogService.ObtenerTiempoDeVida(descripcion);
                
                if (tiempoDeVidaExistente.StatusCode == HttpStatusCode.OK)
                {
                    TiempoDeVidaResponseDto result = JsonConvert.DeserializeObject<TiempoDeVidaResponseDto>(tiempoDeVidaExistente.Content.ToString());

                    if (result.tiempoDeVidaDto == null) return false;

                    if (result.tiempoDeVidaDto.TiempoDeVidaId == 0)
                    {
                        await _iApiLogService.IngresarTiempoDeVida(new TiempoDeVidaDto()
                        {
                            Descripcion = descripcion,
                            UltimaActividad = DateTime.Now
                        });
                    }
                    else
                    {
                        result.tiempoDeVidaDto.UltimaActividad = DateTime.Now;
                        await _iApiLogService.ActualizarTiempoDeVida(result.tiempoDeVidaDto);
                    }
                    return true;

                }
                else return false;
            }
            catch
            {
                return false;
            }
        }
    }
}
