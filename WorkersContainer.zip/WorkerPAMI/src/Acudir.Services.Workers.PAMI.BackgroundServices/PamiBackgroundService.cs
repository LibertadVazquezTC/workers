﻿
using System.ComponentModel.DataAnnotations;
using System.Net;
using Acudir.Services.Worker.PAMI.Domain.Acudir;
using Acudir.Services.Worker.PAMI.Domain.Enums;
using Acudir.Services.Worker.PAMI.Domain.Pami;
using Acudir.Services.Workers.PAMI.BackgroundServices.Extensions;
using Acudir.Services.Workers.PAMI.Domain.Acudir;
using Acudir.Services.Workers.PAMI.Services.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Refit;

namespace Acudir.Services.Workers.PAMI.BackgroundServices
{
    public class PamiBackgroundService : BackgroundService
    {
        private readonly ILogger<PamiBackgroundService> _logger;
        private readonly IConfiguration _configuration;
        private readonly ITiempoDeVidaService _tiempoDeVidaService;
        private readonly string _secondsGestionarNotificaciones;
        private readonly string _secondsNotificarTiempoLimiteSLA;
        private readonly string apiPamiUrl;
        private readonly IPAMIApiRestService _iApiPamiService;
        private readonly string apiLoggerUrl;
        private readonly ILogApiRestService _iApiLogService;

        private bool runningGestionarIncidentes = false;
        private bool runningNotificarArribo = false;

        public PamiBackgroundService(ILogger<PamiBackgroundService> logger, IConfiguration configuration, ITiempoDeVidaService tiempoDeVidaService, PamiSettings settings)
        {
            _configuration = configuration;
            apiPamiUrl = settings.ApiPamiUrl ?? throw new Exception($"La url de ApiPami no existe.");
            _iApiPamiService = RestService.For<IPAMIApiRestService>(apiPamiUrl);
            apiLoggerUrl = settings.ApiLoggerUrl ?? throw new Exception($"La url de ApiLogger no existe.");
            _iApiLogService = RestService.For<ILogApiRestService>(apiLoggerUrl);
            _logger = logger;
            _tiempoDeVidaService = tiempoDeVidaService;
            _secondsGestionarNotificaciones = settings.Seconds.GestionarNotificaciones ?? throw new Exception($"No se encontraron segundos.");
            _secondsNotificarTiempoLimiteSLA = settings.Seconds.NotificarTiempoLimiteSLA ?? throw new Exception($"No se encontraron segundos.");
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Acudir.Services.Workers.PAMI Starting at: {time}", DateTimeOffset.Now);

            await Task.Run(() =>
                Task.WaitAll(new Task[] {
                    gestionarIncidentesBackgroundProcessing(stoppingToken),
                    notificarEstadoPendienteSlaBackgroundProcessing(stoppingToken)
                }, stoppingToken)
            , stoppingToken);
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            runningGestionarIncidentes = false;
            runningNotificarArribo = false;

            _logger.LogInformation("Acudir.Services.Workers.PAMI Stoping at: {time}", DateTimeOffset.Now);

            return base.StopAsync(cancellationToken);
        }

        public async Task<bool> IsRunning()
        {
            return await Task.FromResult<bool>(runningGestionarIncidentes && runningNotificarArribo);
        }

        public async void Start()
        {
            _logger.LogInformation("Starting manually", DateTimeOffset.Now);
            CancellationTokenSource token = new CancellationTokenSource();
            await this.StartAsync(token.Token);
        }

        public async void Stop()
        {
            _logger.LogInformation("Stopping manually", DateTimeOffset.Now);
            CancellationTokenSource token = new CancellationTokenSource();
            await this.StopAsync(token.Token);
        }

        #region Background Tasks

        /// <summary>
        /// 
        /// </summary>
        /// <param name="stoppingToken"></param>
        /// <returns></returns>
        private async Task gestionarIncidentesBackgroundProcessing(CancellationToken stoppingToken)
        {
            try
            {
                runningGestionarIncidentes = true;

                while (runningGestionarIncidentes && !stoppingToken.IsCancellationRequested)
                {
                    using (PeriodicTimer timer = new PeriodicTimer(TimeSpan.FromSeconds(Int32.Parse(_secondsGestionarNotificaciones))))
                    {
                        while (runningGestionarIncidentes && await timer.WaitForNextTickAsync(stoppingToken))
                        {
                            await gestionarIncidentesEnCurso();
                            await gestionarNotificaciones();
                            await _tiempoDeVidaService.IngresarTiempoDeVida();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);

                if (runningGestionarIncidentes) this.Start();
            }
        }

        private async Task notificarEstadoPendienteSlaBackgroundProcessing(CancellationToken stoppingToken)
        {
            try
            {
                runningNotificarArribo = true;

                while (runningNotificarArribo && !stoppingToken.IsCancellationRequested)
                {
                    using (PeriodicTimer timer = new PeriodicTimer(TimeSpan.FromSeconds(Int32.Parse(_secondsNotificarTiempoLimiteSLA))))
                    {
                        while (runningNotificarArribo && await timer.WaitForNextTickAsync(stoppingToken))
                        {
                            await this.notificarEstadoPendienteTiempoSLA();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);

                if (runningNotificarArribo) this.Start();
            }
        }

        #endregion

        #region Notificaciones Entrantes

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private async Task notificarArriboPamiTiempoLimite()
        {
            try
            {
                var pedido = await this.obtenerIncidentePrioritario();
                if (pedido == null || pedido.PedidoId == 0)
                {
                    _logger.LogInformation("No hay pedidos para informar");
                }
                else
                {
                    var arriboTechmed = await this.validarSiPedidoTechmedArribo(pedido.PedidoId);

                    if (!arriboTechmed)
                    {
                        int? tiempoRestante = null;

                        var incidentePami = await _iApiLogService.ObtenerIncidente(pedido.NroIncidente);

                        var horarios = JsonConvert.DeserializeObject<IEnumerable<AssignmentStatesDTO>>(incidentePami.Content!.JsonHorariosPami);

                        var horarioFaltante = horarios.OrderBy(u => u.order).Where(x => x.timeReported == null).FirstOrDefault();

                        if (horarioFaltante != null)
                        {
                            if (horarioFaltante?.description == EstadosEnum.RumboAIncidente.GetAttribute<DisplayAttribute>().Description)
                            {
                                var notificarFechaInicioViaje = await _iApiPamiService.IngresarIncidenteEstado(pedido.NroIncidente, EstadosEnum.RumboAIncidente.GetAttribute<DisplayAttribute>().Description);
                                if (notificarFechaInicioViaje.isSuccess)
                                {
                                    _logger.LogInformation($"Notificar arribo. El estado {horarioFaltante!.description} del incidente {pedido.NroIncidente} se notifico exitosamente");
                                }
                                else
                                {
                                    _logger.LogError($"Ocurrio un error al intentar notificar el estado { horarioFaltante!.description } del incidente {pedido.NroIncidente}. Error: {notificarFechaInicioViaje.message}");
                                    return;
                                }
                            }
                        }

                        switch (pedido.TipoPrestacion)
                        {
                            case "Rojo":
                                tiempoRestante = (pedido.HoraToma.AddMinutes(15) - DateTime.Now).Minutes;
                                break;
                            case "Rojo Pediatrico":
                                tiempoRestante = (pedido.HoraToma.AddMinutes(15) - DateTime.Now).Minutes;
                                break;
                            case "Amarillo":
                                tiempoRestante = (pedido.HoraToma.AddMinutes(45) - DateTime.Now).Minutes;
                                break;
                            case "Amarillo Pediatrico":
                                tiempoRestante = (pedido.HoraToma.AddMinutes(45) - DateTime.Now).Minutes;
                                break;
                        }

                        _logger.LogInformation("Sleeping...");

                        if (tiempoRestante >= 1 && tiempoRestante < 2)
                        {
                            await Task.Run(() => Thread.Sleep(new Random().Next(3000) * 15));
                        }
                        else if (tiempoRestante >= 2)
                        {
                            await Task.Run(() => Thread.Sleep(new Random().Next(3000) * 30));
                        }

                        var notificarEstado = await _iApiPamiService.IngresarIncidenteEstado(pedido.NroIncidente, EstadosEnum.EnIncidente.GetAttribute<DisplayAttribute>().Description);
                        if (notificarEstado.isSuccess)
                        {
                            _logger.LogInformation("Notificar arribo. El estado se notifico exitosamente");

                            var incidente = await _iApiPamiService.GetIncidenteById(pedido.NroIncidente);

                            await _iApiLogService.ActualizarJsonHorariosPami(int.Parse(pedido.NroIncidente), new ActualizarJsonHorariosPamiDto()
                            {
                                JsonHorariosPami = JsonConvert.SerializeObject(incidente.assignmentStates)
                            });

                            _logger.LogInformation($"Se actualizo exitosamente el incidente {pedido.NroIncidente} en la base de datos.");
                        }
                        else
                        {
                            _logger.LogError($"Ocurrio un error al intentar notificar el estado del incidente {pedido.NroIncidente}. Error: {notificarEstado.message}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                _logger.LogError(ex, "NotificarArriboPamiTiempoLimite");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private async Task notificarEstadoPendiente(string estado, string nroIncidente, int pedidoId, string tipoPrestacion, DateTime horaToma)
        {
            try
            {
                //verifico que no se haya informado por el proceso principal
                var incidentePami = await _iApiLogService.ObtenerIncidente(nroIncidente);
                var horarios = JsonConvert.DeserializeObject<IEnumerable<AssignmentStatesDTO>>(incidentePami.Content!.JsonHorariosPami);
                var horarioFaltante = horarios.OrderBy(u => u.order).Where(x => x.timeReported == null).FirstOrDefault();

                if (horarioFaltante != null && horarioFaltante?.description == estado)
                {
                    if (estado == "En incidente")
                    {
                        var tiempoRestante = 0;
                        switch (tipoPrestacion)
                        {
                            case "Rojo":
                                tiempoRestante = (horaToma.AddMinutes(15) - DateTime.Now).Minutes;
                                break;
                            case "Amarillo":
                                tiempoRestante = (horaToma.AddMinutes(45) - DateTime.Now).Minutes;
                                break;
                        }

                        _logger.LogInformation("Sleeping...");

                        if (tiempoRestante >= 1 && tiempoRestante < 2)
                        {
                            await Task.Run(() => Thread.Sleep(new Random().Next(3000) * 15));
                        }
                        else if (tiempoRestante >= 2)
                        {
                            await Task.Run(() => Thread.Sleep(new Random().Next(3000) * 30));
                        }
                    }

                    var notificarEstado = await _iApiPamiService.IngresarIncidenteEstado(nroIncidente, estado);
                    if (notificarEstado.isSuccess)
                    {
                        _logger.LogInformation($"NotificarEstadoPendiente {estado}: estado del incidente {nroIncidente} se notifico exitosamente");

                        var incidente = await _iApiPamiService.GetIncidenteById(nroIncidente);

                        await _iApiLogService.ActualizarJsonHorariosPami(int.Parse(nroIncidente), new ActualizarJsonHorariosPamiDto()
                        {
                            JsonHorariosPami = JsonConvert.SerializeObject(incidente.assignmentStates)
                        });

                        _logger.LogInformation($"NotificarEstadoPendiente: Se actualizo exitosamente el incidente {nroIncidente} en la base de datos.");
                    }
                    else
                    {
                        _logger.LogError($"NotificarEstadoPendiente {estado}: Ocurrio un error al intentar notificar el estado del incidente {nroIncidente}. Error: {notificarEstado.message}");
                    }
                }
                else _logger.LogError($"NotificarEstadoPendiente {estado}: {nroIncidente} - El estado no coincide con el estado a informar");
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private async Task notificarEstadoPendienteTiempoSLA()
        {
            try
            {
                string[] estados = { "Despachado", "Rumbo a incidente", "En incidente" };

                foreach (var estado in estados)
                {
                    var pedidoPendienteDespachar = await this.obtenerPedidoPendienteInformar(estado);
                    if (pedidoPendienteDespachar != null && pedidoPendienteDespachar?.PedidoId != 0)
                    {
                        await this.notificarEstadoPendiente(estado, pedidoPendienteDespachar.NroIncidente, pedidoPendienteDespachar.PedidoId, pedidoPendienteDespachar.TipoPrestacion, pedidoPendienteDespachar.Fecha);
                    }
                    else
                    {
                        _logger.LogInformation($"NotificarEstadoPendienteTiempoSLA: {estado} > No hay pedidos para notificar.");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("NotificarEstadoPendienteTiempoSLA: ", ex.Message);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private async Task gestionarNotificaciones()
        {
            try
            {
                GetPendingDTO notificaciones = await obtenerEntrantes();
               
                if (notificaciones != null)
                {
                    if (notificaciones.isSuccess)
                    {
                        await incidentesNuevos(notificaciones);
                        await incidentesAnulados(notificaciones);
                        await incidentesReclamados(notificaciones);
                        await incidentesReiterados(notificaciones);
                    }
                    else
                    {
                        _logger.LogWarning($"Error al cargar las notificaciones de PAMI. Detalle del error {notificaciones.message}.");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogCritical($"GestionarNotificaciones {ex.Message}");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="notificaciones"></param>
        /// <returns></returns>
        private async Task incidentesNuevos(GetPendingDTO notificaciones)
        {
            //Agarra los incidentes nuevos
            var notifications = notificaciones.notifications.Where(x => x.notificationType == "Nuevo").Where(x => !x.serviceID.Contains('/')).ToArray();

            if (notifications.Any())
            {
                for (int i = 0; i < notifications.Length; i++)
                {
                    var notification = notifications[i];
                    try
                    {
                        var incidenteId = await _iApiLogService.CrearLog(notification.serviceID, new CrearLogDto() { JsonNotificacionPami = JsonConvert.SerializeObject(notification) }); //Ingresado

                        if (incidenteId == 0) continue;

                        var incidentePami = await _iApiPamiService.GetIncidenteById(notification.serviceID);

                    if (incidentePami.isSuccess)
                    {
                        await _iApiLogService.ActualizarJsonIncidentePami(incidenteId, new ActualizarJsonIncidentePamiDto() { JsonIncidentePami = JsonConvert.SerializeObject(incidentePami) });
                        _logger.LogInformation($"Datos obtenidos satisfactioriamente. Enviando el incidente ({notification.serviceID}) al sistema de Acudir");

                        //Creacion
                        var pedidoId = await _iApiPamiService.ConvertirEnAcudir(incidentePami, notification.serviceID);
                        if (pedidoId == 0)
                        {
                            var mensajeError = $"Fallo al generar el incidente ({notification.serviceID}) en el sistema de Acudir";
                            _logger.LogError(mensajeError);
                            await _iApiLogService.IngresarError(new IngresarErrorDto() { NroIncidente = incidenteId, Message = mensajeError });
                            await _iApiPamiService.NotificarErrorAlCrear(notification.serviceID, mensajeError);
                        }

                        await _iApiLogService.IngresarFechaCreacion(incidenteId, pedidoId);
                        _logger.LogInformation($"Pedido Acudir ({pedidoId}) generado con éxito.");

                        //Confirmacion
                        await _iApiPamiService.Reconocer(notification);
                        await _iApiLogService.IngresarFechaConfirmacion(incidenteId);
                        _logger.LogInformation($"Incidente ({notification.serviceID}) confirmado a PAMI");

                        //actualizo el DTO
                        incidentePami = await _iApiPamiService.GetIncidenteById(notification.serviceID);
                        await _iApiLogService.ActualizarJsonHorariosPami(incidenteId, new ActualizarJsonHorariosPamiDto() { JsonHorariosPami = JsonConvert.SerializeObject(incidentePami.assignmentStates) });
                        _logger.LogInformation($"Incidente ({notification.serviceID}) actualizado satisfactoriamente.");
                    }
                    else
                    {
                        throw new Exception(incidentePami.message);
                    }
                }
                    catch (Exception ex)
                    {
                    var incidenteException = await _iApiLogService.ObtenerIncidente(notification.serviceID);

                    if (incidenteException == null)
                    //si no existia lo creo, registro la fecha del error y mando el mail
                    {
                        int incidenteErrorId = await _iApiLogService.CrearLog(notification.serviceID, new CrearLogDto() { JsonNotificacionPami = ex.Message });
                        if (incidenteErrorId == 0) continue;

                        //creo el incidente
                        await _iApiLogService.IngresarError(new IngresarErrorDto() { NroIncidente = incidenteErrorId, Message = $"No se encontro un log previo. Error: {ex.Message}" });
                        _logger.LogWarning($"Fallo en la anulación del incidente {notification.serviceID}, no se encontraron registros en el log. {ex.Message}");
                    }

                    if (incidenteException != null && incidenteException.Content.FechaError == null)
                    //si existe pero no tenia una fecha de error, notifico el error
                    {
                        await _iApiLogService.IngresarError(new IngresarErrorDto() { NroIncidente = incidenteException.Content.IncidentePamiId, Message = $"Error: {ex.Message}" });
                        _logger.LogWarning($"Fallo en la gestion del incidente {notification.serviceID}. {ex.Message}");
                    }
                }
            }
        }
        //TODO: Agarrar las rederivaciones 
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="notificaciones"></param>
    /// <returns></returns>
    private async Task incidentesAnulados(GetPendingDTO notificaciones)
    {
        var anulados = notificaciones.notifications.Where(x => x.notificationType == "Anulación");

        foreach (var notificacion in anulados)
        {
            try
            {
                var incidente = await _iApiLogService.ObtenerIncidente(notificacion.serviceID);
                if (incidente.StatusCode == HttpStatusCode.OK)
                {
                    if (incidente.Content!.IncidenteAcudir != null)
                    {
                        var resultado = await _iApiPamiService.EnviarSolicitudDeAnulacion((int)incidente.Content.IncidenteAcudir);
                        if (resultado)
                        {
                            await _iApiLogService.IngresarAnulacion(incidente.Content.IncidentePamiId);
                            await _iApiPamiService.Reconocer(notificacion);
                        }
                        return;
                    }
                    else
                    {
                        throw new Exception($"Ocurrio un error al anular el incidente de pami {incidente.Content.NroIncidentePami}. No se encontró el pedido Acudir relacionado.");
                    }
                }
            }
            catch (Exception ex)
            {
                var incidenteException = await _iApiLogService.ObtenerIncidente(notificacion.serviceID);

                if (incidenteException == null)
                //si no existia lo creo, registro la fecha del error y mando el mail
                {
                    int incidenteErrorId = await _iApiLogService.CrearLog(notificacion.serviceID, new CrearLogDto() { JsonNotificacionPami = ex.Message }); //creo el incidente
                    if (incidenteErrorId == 0) continue;

                    await _iApiLogService.IngresarError(new IngresarErrorDto() { Message = $"No se encontro un log previo. Error: {ex.Message}" });
                    _logger.LogWarning($"Fallo en la anulación del incidente {notificacion.serviceID}, no se encontraron registros en el log. {ex.Message}");
                }

                if (incidenteException != null && incidenteException.Content.FechaError == null)
                //si existe pero no tenia una fecha de error, notifico el error
                {
                    await _iApiLogService.IngresarError(new IngresarErrorDto() { NroIncidente = incidenteException.Content.IncidentePamiId, Message = $"Error: {ex.Message}" });
                    _logger.LogWarning($"Fallo en la anulación del incidente {notificacion.serviceID}, no se encontró el pedido Acudir. {ex.Message}");
                }
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="notificaciones"></param>
    /// <returns></returns>
    private async Task incidentesReclamados(GetPendingDTO notificaciones)
    {
        var reclamos = notificaciones.notifications.Where(x => x.notificationType == "Reclamo").ToArray();

        for (int i = 0; i < reclamos.Length; i++)
        {
            var notificacion = reclamos[i];

            try
            {
                var incidente = await _iApiLogService.ObtenerIncidente(notificacion.serviceID);
                if (incidente.StatusCode == HttpStatusCode.OK)
                {
                    if (incidente.Content!.IncidenteAcudir != null)
                    {
                        var resultado = await _iApiPamiService.IngresarReclamo((int)incidente.Content.IncidenteAcudir, "Reclamo solicitado por PAMI");
                        if (resultado)
                        {
                            var respuestaACK = await _iApiPamiService.Reconocer(notificacion);
                            if (!respuestaACK.isSuccess)
                                _logger.LogWarning($"Fallo en el ACK");
                        }
                    }
                    else
                    {
                        throw new Exception($"Ocurrio un error al ingresar el reclamo para el incidente de pami {incidente.Content.NroIncidentePami}.");
                    }
                }


            }
            catch (Exception ex)
            {
                var incidenteException = await _iApiLogService.ObtenerIncidente(notificacion.serviceID);

                if (incidenteException == null)
                //si no existia lo creo, registro la fecha del error y mando el mail
                {
                    int incidenteErrorId = await _iApiLogService.CrearLog(notificacion.serviceID, new CrearLogDto() { JsonNotificacionPami = ex.Message }); //creo el incidente
                    if (incidenteErrorId == 0) continue;

                    await _iApiLogService.IngresarError(new IngresarErrorDto() { NroIncidente = incidenteErrorId, Message = $"No se encontro un log previo. Error: {ex.Message}" });
                    _logger.LogWarning($"Fallo en el ingreso del reclamo al incidente {notificacion.serviceID}, no se encontraron registros en el log. {ex.Message}");
                }

                if (incidenteException?.Content?.FechaError == null)
                //si existe pero no tenia una fecha de error, notifico el error
                {
                    await _iApiLogService.IngresarError(new IngresarErrorDto() { NroIncidente = incidenteException.Content.IncidentePamiId, Message = $"Error: No se encontró el servicio de acudir asociado al reclamo ({ex.Message})" });
                    _logger.LogWarning($"Fallo en el ingreso del reclamo al incidente {notificacion.serviceID}, no se encontró el pedido Acudir. {ex.Message}");
                }
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="notificaciones"></param>
    /// <returns></returns>
    private async Task incidentesReiterados(GetPendingDTO notificaciones)
    {
        var reiteraciones = notificaciones.notifications.Where(x => x.notificationType == "Reiteración").ToArray();

        for (int i = 0; i < reiteraciones.Length; i++)
        {
            var notificacion = reiteraciones[i];
            try
            {
                var incidente = await _iApiLogService.ObtenerIncidente(notificacion.serviceID);

                if (incidente.StatusCode == HttpStatusCode.OK)
                {
                    if (incidente != null && incidente.Content!.IncidenteAcudir != null)
                    {
                        var incidentePami = await _iApiPamiService.GetIncidenteById(notificacion.serviceID);

                        if (incidentePami.isSuccess)
                        {
                            await _iApiLogService.IngresarReiteracion(incidente.Content.IncidentePamiId, new IngresarReiteracionDto() { JsonReiteracionIncidentePami = JsonConvert.SerializeObject(incidentePami) });
                            await _iApiPamiService.NotificarReiteracion(incidente.Content);
                            await _iApiPamiService.Reconocer(notificacion);
                        }
                    }
                    else
                    {
                        throw new Exception($"Ocurrio un error al ingresar la reiteracion para el incidente de pami {incidente.Content.NroIncidentePami}.");
                    }
                }
            }
            catch (Exception ex)
            {
                var incidenteException = await _iApiLogService.ObtenerIncidente(notificacion.serviceID);

                if (incidenteException == null)
                //si no existia lo creo, registro la fecha del error y mando el mail
                {
                    int incidenteErrorId = await _iApiLogService.CrearLog(notificacion.serviceID, new CrearLogDto() { JsonNotificacionPami = ex.Message }); //creo el incidente
                    if (incidenteErrorId == 0) continue;

                    await _iApiLogService.IngresarError(new IngresarErrorDto() { NroIncidente = incidenteErrorId, Message = $"No se encontro un log previo. Error: {ex.Message}" });
                    _logger.LogWarning($"Fallo en el ingreso de la reiteración al incidente {notificacion.serviceID}, no se encontraron registros en el log. {ex.Message}");
                }

                if (incidenteException != null && incidenteException.Content.FechaError == null)
                //si existe pero no tenia una fecha de error, notifico el error
                {
                    await _iApiLogService.IngresarError(new IngresarErrorDto() { NroIncidente = incidenteException.Content.IncidentePamiId, Message = $"Error: No se encontró el servicio de acudir asociado a la reiteracion ({ex.Message})" });
                    _logger.LogWarning($"Fallo en el ingreso de la reiteración al incidente {notificacion.serviceID}, no se encontró el pedido Acudir. {ex.Message}");
                }
            }
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    private async Task<GetPendingDTO> obtenerEntrantes()
    {
        try
        {
            var entrantes = await _iApiPamiService.GetIncidentesPendientes();

            if (!entrantes.isSuccess)
            {
                _logger.LogWarning($"La respuesta de servicios entrantes fue negativa ({entrantes.message})");
                return null;
            }

            entrantes.notifications.Where(x => !x.serviceID.Contains('/')); //ignorar rederivaciones entrantes

            return entrantes;
        }
        catch (Exception ex)
        {
            _logger.LogWarning($"Reintentando > {ex.Message}");
            return null;
        }
    }

    #endregion

    #region Incidentes en Curso

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    private async Task<GetOngoingDTO> obtenerEnCurso()
    {
        try
        {
            var enCurso = await _iApiPamiService.ObtenerIncidentesEnCurso();

                if (!enCurso.isSuccess)
            {
                _logger.LogWarning($"La respuesta de servicios entrantes fue negativa ({enCurso.message})");
                return null;
            }

            enCurso.summary = enCurso.summary.Where(x => !x.id.Contains('/')); //ignorar rederivaciones en curso
            return enCurso;
        }
        catch (Exception ex)
        {
            _logger.LogWarning($"Reitentando > {ex.Message}");
            return null;
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="enCurso"></param>
    /// <returns></returns>
    private async Task gestionarIncidentesEnCurso()
    {
        try
        {
            GetOngoingDTO getOngoing = await obtenerEnCurso();

            if (getOngoing != null && getOngoing.summary.Any())
            {
                var enCurso = getOngoing.summary.ToArray();
                var incidentesEnCurso = 0;

                for (int i = 0; i < enCurso.Length; i++)
                {
                    var item = enCurso[i];
                        if (string.IsNullOrEmpty(item.id)) continue;
                    var incidentePami = await _iApiLogService.ObtenerIncidente(item.id);

                    if (incidentePami == null)
                    {
                        _logger.LogInformation($"El incidente {item.id} no se encontraba en nuestra base de Datos");

                        var incidente = await _iApiPamiService.GetIncidenteById(item.id);

                        if (incidente.isSuccess)
                        {
                            var incidentePamiId = await _iApiLogService.CrearLog(item.id, new CrearLogDto() { JsonNotificacionPami = "" });

                            if (incidentePamiId == 0) continue;

                            await _iApiLogService.ActualizarJsonIncidentePami(incidentePamiId, new ActualizarJsonIncidentePamiDto() { JsonIncidentePami = JsonConvert.SerializeObject(incidente) });
                            await _iApiLogService.ActualizarJsonHorariosPami(incidentePamiId, new ActualizarJsonHorariosPamiDto() { JsonHorariosPami = JsonConvert.SerializeObject(incidente.assignmentStates) });

                            _logger.LogInformation($"El incidente {item.id} fue creado con éxito");
                        }
                    }
                    else if (incidentePami != null && incidentePami.Content?.IncidenteAcudir != null && incidentePami.Content?.FechaFinalizacion == null && incidentePami.Content?.FechaError == null)
                    //si existe, tiene un pedido y no finalizó 
                    {
                        var horarios = JsonConvert.DeserializeObject<IEnumerable<AssignmentStatesDTO>>(incidentePami.Content.JsonHorariosPami);

                        _logger.LogDebug($"Horarios: {horarios?.Any()} del incidente {incidentePami.Content.NroIncidentePami}");

                        if (horarios != null)
                        {
                            if (!horarios.Any(x => x.description == EstadosEnum.Disponible.GetAttribute<DisplayAttribute>().Description && x.timeReported != null))
                            {
                                var horarioFaltante = horarios.OrderBy(u => u.order).Where(x => x.timeReported == null).FirstOrDefault();

                                if (horarioFaltante != null)
                                {
                                    incidentesEnCurso++;
                                    //si ya tiene el horario de partida es porque no tuvo derivacion, entonces busco disponible, si es que no finalizó
                                    if (horarioFaltante.description == EstadosEnum.EnEsperaDeDerivacion.GetAttribute<DisplayAttribute>().Description && horarios.Any(x => x.description == EstadosEnum.RumboABase.GetAttribute<DisplayAttribute>().Description && x.timeReported != null))
                                    {
                                        horarioFaltante = horarios.FirstOrDefault(x => x.description == EstadosEnum.Disponible.GetAttribute<DisplayAttribute>().Description && x.timeReported == null);
                                    }

                                    if (!string.IsNullOrWhiteSpace(horarioFaltante.description))
                                    {
                                        string estado = await _iApiPamiService.ObtenerEstado((int)incidentePami.Content.IncidenteAcudir, horarioFaltante.description);

                                        if (!string.IsNullOrWhiteSpace(estado))
                                        {
                                            var respuesta = await _iApiPamiService.IngresarIncidenteEstado(incidentePami.Content.NroIncidentePami, estado);

                                            if (respuesta != null)
                                            {
                                                if (!respuesta.isSuccess) _logger.LogInformation($"No se pudo informar el incidente {incidentePami.Content.IncidentePamiId}, error: {respuesta.message}");

                                                var jsonPami = await _iApiPamiService.GetIncidenteById(incidentePami.Content.NroIncidentePami);
                                                await _iApiLogService.ActualizarJsonHorariosPami(incidentePami.Content.IncidentePamiId, new ActualizarJsonHorariosPamiDto() { JsonHorariosPami = JsonConvert.SerializeObject(jsonPami.assignmentStates) });
                                            }
                                        }
                                        else if (!string.IsNullOrWhiteSpace(estado) && horarioFaltante.description == "En incidente" && estado != "En incidente")
                                        {
                                            //a veces el json de pami tarda en actualizar del lado de ellos, vuelvo a preguntar los estados para poder actualizarlo y pasar al siguiente estado
                                            var jsonPami = await _iApiPamiService.GetIncidenteById(incidentePami.Content.NroIncidentePami);
                                            await _iApiLogService.ActualizarJsonHorariosPami(incidentePami.Content.IncidentePamiId, new ActualizarJsonHorariosPamiDto() { JsonHorariosPami = JsonConvert.SerializeObject(jsonPami.assignmentStates) });
                                        }
                                    }
                                }
                                await buscarSegundoPuntoPrimerTramo(item.id);
                            }
                            else
                            {
                                string message = $"El incidente {incidentePami.Content.NroIncidentePami} esta informado como disponible en PAMI, pero no se registró en Acudir.";

                                _logger.LogInformation(message);

                                await _iApiLogService.IngresarError(new IngresarErrorDto()
                                {
                                    NroIncidente = incidentePami.Content.IncidentePamiId,
                                    Message = message
                                });

                                await _iApiPamiService.NotificarErrorAlCrear(incidentePami.Content.NroIncidentePami, message);
                            }
                        }
                    }
                    else
                    {
                        if (incidentePami.Content.FechaFinalizacion != null && incidentePami.Content.FechaError == null)
                        {
                            var jsonString = await _iApiPamiService.ObtenerEstado((int)incidentePami.Content.IncidenteAcudir, "Archivado");

                            if (!string.IsNullOrEmpty(jsonString))
                            {
                                var cierreDTO = JsonConvert.DeserializeObject<CierreDTO>(jsonString);

                                cierreDTO.UrgencyDegreeCode = await _iApiPamiService.ObtenerGradoUrgencia(cierreDTO.PedidoTipoCierreId);
                                cierreDTO.DiagnosticCode = await _iApiPamiService.ObtenerDiagnostico(cierreDTO.DiagnosticoId);

                                if (cierreDTO.SanatorioId != 0)
                                {
                                    cierreDTO.HeathcareCenter = await _iApiPamiService.ObtenerSanatorio(cierreDTO.SanatorioId);

                                    var respuestaCentroSalud = await _iApiPamiService.IngresarIncidenteCentroSalud(incidentePami.Content.NroIncidentePami, cierreDTO.HeathcareCenter);
                                    if (respuestaCentroSalud.isSuccess)
                                    {
                                        var jsonPami = await _iApiPamiService.GetIncidenteById(incidentePami.Content.NroIncidentePami);
                                        await _iApiLogService.ActualizarJsonIncidentePami(incidentePami.Content.IncidentePamiId, new ActualizarJsonIncidentePamiDto() { JsonIncidentePami = JsonConvert.SerializeObject(jsonPami) });
                                    }
                                    else _logger.LogInformation($"Ocurrio un error al ingresar el centro de salud {respuestaCentroSalud.message}");
                                }
                                else
                                {
                                    var respuestaCentroSalud = await _iApiPamiService.IngresarIncidenteCentroSalud(incidentePami.Content.NroIncidentePami, "Sin definir");
                                    if (respuestaCentroSalud.isSuccess)
                                    {
                                        var jsonPami = await _iApiPamiService.GetIncidenteById(incidentePami.Content.NroIncidentePami);
                                        await _iApiLogService.ActualizarJsonIncidentePami(incidentePami.Content.IncidentePamiId, new ActualizarJsonIncidentePamiDto() { JsonIncidentePami = JsonConvert.SerializeObject(jsonPami) });
                                    }
                                    else _logger.LogInformation($"Ocurrio un error al ingresar el centro de salud {respuestaCentroSalud.message}");
                                }

                                var respuestaDiagnostico = await _iApiPamiService.IngresarIncidenteDiagnosticoGradoUrgencia(incidentePami.Content.NroIncidentePami, cierreDTO.DiagnosticCode, cierreDTO.UrgencyDegreeCode);
                                if (respuestaDiagnostico.isSuccess)
                                {
                                    var jsonPami = await _iApiPamiService.GetIncidenteById(incidentePami.Content.NroIncidentePami);
                                    await _iApiLogService.ActualizarJsonIncidentePami(incidentePami.Content.IncidentePamiId, new ActualizarJsonIncidentePamiDto() { JsonIncidentePami = JsonConvert.SerializeObject(jsonPami) });
                                }
                                else _logger.LogInformation($"Ocurrio un error al ingresar el diagnostico {respuestaDiagnostico.message}");

                                cierreDTO.FinalDestinationCode = await _iApiPamiService.ObtenerDestinoFinal(cierreDTO.PedidoTipoCierreId);
                                var respuestaDestinoFinal = await _iApiPamiService.IngresarIncidenteDestinoFinal(incidentePami.Content.NroIncidentePami, cierreDTO.FinalDestinationCode);

                                if (respuestaDestinoFinal.isSuccess)
                                {
                                    var jsonPami = await _iApiPamiService.GetIncidenteById(incidentePami.Content.NroIncidentePami);
                                    await _iApiLogService.ActualizarJsonIncidentePami(incidentePami.Content.IncidentePamiId, new ActualizarJsonIncidentePamiDto() { JsonIncidentePami = JsonConvert.SerializeObject(jsonPami) });
                                }
                                else _logger.LogInformation($"Ocurrio un error al ingresar el destino final {respuestaDestinoFinal.message}");

                                var respuestaCierre = await _iApiPamiService.Finalizar(incidentePami.Content.NroIncidentePami);
                                if (respuestaCierre.isSuccess)
                                {
                                    await _iApiLogService.IngresarCierre(incidentePami.Content.IncidentePamiId, new IngresarCierreDto() { Cierre = JsonConvert.SerializeObject(cierreDTO) });
                                }
                                else
                                {
                                    _logger.LogInformation($"Error en el cierre del incidente {incidentePami.Content.NroIncidentePami}. Mensaje: {respuestaCierre.message}. JsonCierre: {JsonConvert.SerializeObject(cierreDTO)}");
                                    await _iApiLogService.IngresarError(new IngresarErrorDto() { NroIncidente = incidentePami.Content.IncidentePamiId, Message = respuestaCierre.message + "DTO de cierre: " + JsonConvert.SerializeObject(cierreDTO) });
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "GestionarIncidentesEnCurso");
        }
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="nroIncidente"></param>
    /// <returns></returns>
    private async Task buscarSegundoPuntoPrimerTramo(string nroIncidente)
    {
        try
        {
            var rumboLugarDeriv = await _iApiPamiService.RumboALugarDeDerivacion(nroIncidente);

            if (rumboLugarDeriv.IsSuccessStatusCode && rumboLugarDeriv.Content)
            {
                var result = await _iApiPamiService.IngresarIncidenteEstado(nroIncidente, EstadosEnum.RumboALugarDeDeriv.GetAttribute<DisplayAttribute>().Description);

                if (result.isSuccess) _logger.LogInformation($"BuscarSegundoPuntoPrimerTramo: El incidente {nroIncidente} esta rumbo al  lugar de derivacion");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "BuscarSegundoPuntoPrimerTramo");
        }

        #endregion
    }

    #region CalcularArribo

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    private async Task<PedidoDTO?> obtenerIncidentePrioritario()
    {
        var incidente = await _iApiPamiService.ObtenerPedidoPrioritario();
        if (incidente.StatusCode == HttpStatusCode.OK)
        {
            var response = incidente.Content.ToString();
            if (response != null || response != "") return JsonConvert.DeserializeObject<PedidoDTO>(response);
            else return null;
        }
        else throw new Exception($"ObtenerIncidentePrioritario > Ocurrio un error {incidente.Error.Message} ");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    private async Task<PedidoPrioritarioDto?> obtenerPedidoPendienteInformar(string estado)
    {
        var incidente = await _iApiPamiService.ObtenerPedidoPamiPendienteInformar(estado);
        if (incidente.StatusCode == HttpStatusCode.OK)
        {
            var response = incidente.Content.ToString();
            if (response != null || response != "") return JsonConvert.DeserializeObject<PedidoPrioritarioDto>(response);
            else return null;
        }
        if (incidente.StatusCode == HttpStatusCode.NoContent)
        {
            return null;
        }
        else throw new Exception($"ObtenerPedidoPendienteInformar: Ocurrio un error: {incidente?.Error}");
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="pedidoId"></param>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    private async Task<bool> validarSiPedidoTechmedArribo(int pedidoId)
    {
        var pedido = await _iApiPamiService.ValidarSiPedidoPamiArribo(pedidoId);

        if (pedido.StatusCode == HttpStatusCode.OK) return pedido.Content;
        else throw new Exception("Ocurrio un error.");
    }

    #endregion
}
}