﻿using Acudir.Services.Workers.PAMI.Services.Dtos;

namespace Acudir.Services.Workers.PAMI.BackgroundServices.Extensions
{
    public class PamiSettings
    {
        public string ApiLoggerUrl { get; set; }
        public string ApiPamiUrl { get; set; }
        public EnvironmentSettings Environment { get; set; }
        public Seconds Seconds { get; set; }
        public WebApiPami WebApiPami{get;set;}

        public PamiSettings(string apiLoggerUrl, string apiPamiUrl, WebApiPami webApiPami, Seconds seconds, EnvironmentSettings environmentSettings)
        {
            this.ApiLoggerUrl = apiLoggerUrl;
            this.ApiPamiUrl = apiPamiUrl;
            this.Environment = new EnvironmentSettings()
            {
                Environment = environmentSettings.Environment,
                ApiLoggerUrl = environmentSettings.ApiLoggerUrl,
            };
            this.WebApiPami = new WebApiPami()
            {
                Password = webApiPami.Password,
                Url = webApiPami.Url,
                Username = webApiPami.Username,
            };
            this.Seconds = new Seconds()
            {
                GestionarNotificaciones = seconds.GestionarNotificaciones,
                NotificarTiempoLimiteSLA = seconds.NotificarTiempoLimiteSLA,
            };
        }
    }
}
