﻿using Acudir.Services.Workers.PAMI.Services;
using Acudir.Services.Workers.PAMI.Services.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Acudir.Services.Workers.PAMI.BackgroundServices.Extensions
{
    public static class PamiConfigurationSettingsService
    {
        public static IServiceCollection ConfigurePamiSettings(this IServiceCollection services, PamiSettings settings)
        {
            services
                .AddSingleton<ITiempoDeVidaService, TiempoDeVidaService>(serviceProvider => new TiempoDeVidaService(settings.Environment))
                .AddSingleton<PamiBackgroundService>(serviceProvider => new PamiBackgroundService(serviceProvider.GetService<ILogger<PamiBackgroundService>>(), serviceProvider.GetService<IConfiguration>(), serviceProvider.GetService<ITiempoDeVidaService>(), settings))
                .AddHostedService(provider => provider.GetRequiredService<PamiBackgroundService>());

            return services;
        }
    }
}