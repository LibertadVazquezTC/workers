﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acudir.Services.Workers.PAMI.BackgroundServices.Extensions
{
    public class Seconds
    {
        public string? GestionarNotificaciones {get;set;}
        public string? NotificarTiempoLimiteSLA { get;set;}
    }
}
