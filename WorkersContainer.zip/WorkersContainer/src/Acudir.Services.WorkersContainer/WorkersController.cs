﻿using Acudir.Services.Workers.AlfaBeta.BackgroundServices;
using Acudir.Services.Workers.CambiaTipoPrestacion.BackgroundServices;
using Acudir.Services.Workers.Coseguro.BackgroundServices;
using Acudir.Services.Workers.PAMI.BackgroundServices;
using Acudir.Services.Workers.VCM.BackgroundServices;
using Microsoft.AspNetCore.Mvc;

namespace Acudir.Services.WorkersContainer
{
    [Route("api/[controller]")]
    public class WorkersController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly PamiBackgroundService _pamiBackgroundService;
        private readonly VideoConsultaMedicaBackgroundService _videoConsultaMedicaBackgroundService;
        private readonly AlfaBetaBackgroundService _alfaBetaBackgroundService;
        private readonly CoseguroBackgroundService _coseguroBackgroundService;
        private readonly CambiaTipoPrestacionBackgroundService _cambiaTipoPrestacionBackgroundService;
        private string _workerVCM;
        private string _workerPami;
        private string _workerAlfaBeta;
        private string _workerCoseguro;
        private string _workerCambiaTipoPrestacion;
        public WorkersController(IConfiguration configuration,
            IServiceProvider service,
            ILogger<VideoConsultaMedicaBackgroundService> logger,
            PamiBackgroundService pamiBackgroundService,
            VideoConsultaMedicaBackgroundService videoConsultaMedicaBackgroundService,
            AlfaBetaBackgroundService alfaBetaBackgroundService,
            CoseguroBackgroundService coseguroBackgroundService,
            CambiaTipoPrestacionBackgroundService cambiaTipoPrestacionBackgroundService
            )
        {
            _configuration = configuration;
            _pamiBackgroundService = pamiBackgroundService;
            _videoConsultaMedicaBackgroundService = videoConsultaMedicaBackgroundService;
            _alfaBetaBackgroundService = alfaBetaBackgroundService;
            _coseguroBackgroundService = coseguroBackgroundService;
            _cambiaTipoPrestacionBackgroundService = cambiaTipoPrestacionBackgroundService;

            var vcm = service.GetServices<VideoConsultaMedicaBackgroundService>().GetType();
            _workerVCM = vcm.Assembly.GetName().Name ?? "No se encontro el servicio VCM";
            var pami = service.GetServices<PamiBackgroundService>().GetType();
            _workerPami = pami.Assembly.GetName().Name ?? "No se encontro el servicio Pami";
            var alfaBeta = service.GetServices<AlfaBetaBackgroundService>().GetType();
            _workerAlfaBeta = alfaBeta.Assembly.GetName().Name ?? "No se encontro el servicio AlfaBeta";
            var coseguro = service.GetService<CoseguroBackgroundService>().GetType();
            _workerCoseguro = coseguro.Assembly.GetName().Name ?? "No se encontro el servicio Coseguro";
            var cambiaTipoPrestacion = service.GetServices<CambiaTipoPrestacionBackgroundService>().GetType();
            _workerCambiaTipoPrestacion = cambiaTipoPrestacion.Assembly.GetName().Name ?? "No se encontro el servicio CambiaTipoPrestacion";
        }
        [HttpGet]
        public IActionResult Workers()
        {
            try
            {
                List<String> backgroundServices = new List<String>();

                if (_workerVCM != null) backgroundServices.Add(_workerVCM);
                if (_workerPami != null) backgroundServices.Add(_workerPami);
                if (_workerAlfaBeta != null) backgroundServices.Add(_workerAlfaBeta);
                if (_workerCoseguro != null) backgroundServices.Add(_workerCoseguro);
                if (_workerCambiaTipoPrestacion != null) backgroundServices.Add(_workerCambiaTipoPrestacion);
                if (backgroundServices.Any()) return Ok(backgroundServices);
                else return NoContent();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }


        [HttpPost]
        [Route("{id}/start")]
        public async Task<IActionResult> Start(string id)
        {
            try
            {
                if (id != _workerVCM && id != _workerPami && id != _workerAlfaBeta && id != _workerCoseguro && id != _workerCambiaTipoPrestacion) throw new Exception("No se encontro el worker solicitado. Por favor revise la lista de workers disponibles.");

                if (id == _workerVCM)
                {
                    var isRunning = await _videoConsultaMedicaBackgroundService.IsRunning();
                    if (!isRunning)
                    {
                        _videoConsultaMedicaBackgroundService.Start();
                    }
                    else return BadRequest("No se puede correr el servicio ya que actualmente se encuentra activo");
                }
                if (id == _workerPami)
                {
                    var isRunning = await _pamiBackgroundService.IsRunning();
                    if (!isRunning)
                    {
                        _pamiBackgroundService.Start();
                    }
                    else return BadRequest("No se puede correr el servicio ya que actualmente se encuentra activo");
                }
                if (id == _workerAlfaBeta)
                {
                    var isRunning =  _alfaBetaBackgroundService.IsRunning().Result;
                    if (!isRunning)
                    {
                        _alfaBetaBackgroundService.Start();
                    }
                    else return BadRequest("No se puede correr el servicio ya que actualmente se encuentra activo");
                }
                if (id == _workerCoseguro)
                {
                    var isRunning = await _coseguroBackgroundService.IsRunning();
                    if (!isRunning)
                    {
                        _coseguroBackgroundService.Start();
                    }
                    else return BadRequest("No se puede correr el servicio ya que actualmente se encuentra activo");
                }
                if (id == _workerCambiaTipoPrestacion)
                {
                    var isRunning = _cambiaTipoPrestacionBackgroundService.IsRunning().Result;
                    if (!isRunning)
                    {
                        _cambiaTipoPrestacionBackgroundService.Start();
                    }
                    else return BadRequest("No se puede correr el servicio ya que actualmente se encuentra activo");
                }

                return Ok($"El servicio {id} se inicio correctamente");
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        [HttpPost]
        [Route("{id}/stop")]
        public async Task<IActionResult> Stop(string id)
        {
            try
            {
                if (id != _workerVCM && id != _workerPami && id != _workerAlfaBeta && id != _workerCoseguro && id != _workerCambiaTipoPrestacion) return BadRequest("No se encontro el worker solicitado. Por favor revise la lista de workers disponibles.");

                if (id == _workerVCM)
                {
                    var isRunning = await _videoConsultaMedicaBackgroundService.IsRunning();
                    if (isRunning)
                    {
                        _videoConsultaMedicaBackgroundService.Stop();
                    }
                    else return BadRequest("No se puede detener el servicio ya que actualmente se encuentra inactivo");
                }
                if (id == _workerPami)
                {
                    var isRunning = await _pamiBackgroundService.IsRunning();
                    if (isRunning)
                    {
                        _pamiBackgroundService.Stop();
                    }
                    else return BadRequest("No se puede detener el servicio ya que actualmente se encuentra inactivo");
                }
                if (id == _workerAlfaBeta)
                {
                    var isRunning =  _alfaBetaBackgroundService.IsRunning().Result;
                    if (isRunning)
                    {
                        _alfaBetaBackgroundService.Stop();
                    }
                    else return BadRequest("No se puede detener el servicio ya que actualmente se encuentra inactivo");
                }
                if (id == _workerCoseguro)
                {
                    var isRunning = await _coseguroBackgroundService.IsRunning();
                    if (isRunning)
                    {
                        _coseguroBackgroundService.Stop();
                    }
                    else return BadRequest("No se puede detener el servicio ya que actualmente se encuentra inactivo");
                }
                if (id == _workerCambiaTipoPrestacion)
                {
                    var isRunning = _cambiaTipoPrestacionBackgroundService.IsRunning().Result;
                    if (isRunning)
                    {
                        _cambiaTipoPrestacionBackgroundService.Stop();
                    }
                    else return BadRequest("No se puede detener el servicio ya que actualmente se encuentra inactivo");
                }

                return Ok($"El servicio {id} se ha pausado correctamente");
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
