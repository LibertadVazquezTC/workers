﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Acudir.Services.Controllers.WorkersContainer
{
    [Route("api/[controller]")]
    public class LogsController : Controller
    {
        [HttpGet]
        public IActionResult Get()
        {
            if (!Directory.Exists("logs")) return NoContent();

            string[] files = Directory.GetFiles("logs");

            return Ok(files.ToList().Select(file =>
            {
                var fileInfo = new FileInfo($@"./{file}");
                return fileInfo.Name;
            }));
        }

        [HttpGet("{filename}")]
        public async Task<IActionResult> GetFilename(string filename)
        {
            string file = Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), "logs", filename);

            if (!Directory.Exists("logs")) return NoContent();

            if (!System.IO.File.Exists(file)) return NoContent();

            byte[] buffer = new byte[] { };

            using (var fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                buffer = new byte[fs.Length];
                await fs.ReadAsync(buffer);
            }

            return Ok(await System.IO.File.ReadAllBytesAsync(file));
        }

        [HttpGet("{filename}/download")]
        public async Task<IActionResult> Download(string filename)
        {
            string file = Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), "logs", filename);

            if (!Directory.Exists("logs")) return NoContent();

            if (!System.IO.File.Exists(file)) return NoContent();

            byte[] buffer = new byte[] { };

            using (var fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                buffer = new byte[fs.Length];
                await fs.ReadAsync(buffer);
            }

            return File(buffer, "text/plain", filename);
        }

        /// <summary>
        /// El valor ingresado debe tener la fecha en formato AAAAMMDD, por ejemplo 20230101
        /// </summary>
        [HttpGet("LogsPorArchivo")]
        public IActionResult LogsPorArchivo(string valor)
        {
            try
            {
                string logPath = $@".\logs\acudir.services.workerscontainer-{valor}.txt";
                string tempLogFile = @".\logs\tempLog.log";
                System.IO.File.Copy(logPath, tempLogFile, true);
                var logs = System.IO.File.ReadAllLines(tempLogFile);
                System.IO.File.Delete(tempLogFile);
                if (logs != null) return Ok(logs);
                else return NoContent();
            }
            catch (System.IO.FileNotFoundException)
            {
                throw new Exception ("No se encontro el archivo para el valor ingresado");
            }
            catch (Exception e)
            {

                throw new Exception(e.Message.ToString());
            }
        }
    }
}

