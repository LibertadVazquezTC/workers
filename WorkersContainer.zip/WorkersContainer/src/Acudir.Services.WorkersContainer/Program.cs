using Acudir.Services.Workers.AlfaBeta.BackgroundServices;
using Acudir.Services.Workers.AlfaBeta.Services;
using Acudir.Services.Workers.AlfaBeta.Services.Interfaces;
using Acudir.Services.Workers.Coseguro.BackgroundServices;
using Acudir.Services.Workers.Coseguro.Services;
using Acudir.Services.Workers.Coseguro.Services.Interfaces;
using Acudir.Services.Workers.CambiaTipoPrestacion.BackgroundServices;
using Acudir.Services.Workers.CambiaTipoPrestacion.Services;
using Acudir.Services.Workers.CambiaTipoPrestacion.Services.Interfaces;
using Acudir.Services.Workers.PAMI.BackgroundServices.Extensions;
using Acudir.Services.Workers.PAMI.Services.Dtos;
using Acudir.Services.Workers.VCM.BackgroundServices;
using Acudir.Services.Workers.VCM.Services;
using Acudir.Services.Workers.VCM.Services.Interfaces;

var builder = WebApplication.CreateBuilder(args);
string environmentValue = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Development";
var builderConfig = new ConfigurationBuilder()
    .SetBasePath(Directory.GetCurrentDirectory())
    .AddJsonFile("appsettings.json")
    .AddJsonFile($"appsettings.{environmentValue}.json");
var configuration = builderConfig.Build();

WebApiPami webApiPamiUrl = new WebApiPami()
{
    Password = configuration.GetValue<string>("PamiSettings:WebApiPami:Password"),
    Url = configuration.GetValue<string>("PamiSettings:WebApiPami:Url"),
    Username = configuration.GetValue<string>("PamiSettings:WebApiPami:UserName"),
};

Seconds secondsPami = new Seconds()
{
    GestionarNotificaciones = configuration.GetValue<string>("PamiSettings:seconds:SecondsGestionarNotificaciones"),
    NotificarTiempoLimiteSLA = configuration.GetValue<string>("PamiSettings:seconds:SecondsNotificarTiempoLimiteSLA"),
};

EnvironmentSettings environment = new EnvironmentSettings()
{
    ApiLoggerUrl = configuration.GetValue<string>("PamiSettings:EnvironmentSettings:ApiLogger") ?? throw new KeyNotFoundException("No se encontró la llave PamiSettings:EnvironmentSettings:ApiLogger"),
    Environment = configuration.GetValue<string>("PamiSettings:EnvironmentSettings:Environment") ?? throw new KeyNotFoundException("No se encontró la llave PamiSettings:EnvironmentSettings:Environment"),
};

// Add services to the container.
//VCM
builder.Services
    .AddSingleton<IPedidosService, PedidosService>()
    .AddSingleton<VideoConsultaMedicaBackgroundService>()
    .AddHostedService(provider => provider.GetRequiredService<VideoConsultaMedicaBackgroundService>());
//Pami
builder.Services
    .ConfigurePamiSettings(new PamiSettings(configuration.GetValue<string>("PamiSettings:ApiLogger"), configuration.GetValue<string>("PamiSettings:ApiPami"), webApiPamiUrl, secondsPami, environment));

//AlfaBeta
//builder.Services
//    .AddSingleton<IAlfaBetaService, AlfaBetaService>()
//    .AddSingleton<AlfaBetaBackgroundService>()
//    .AddHostedService(provider => provider.GetRequiredService<AlfaBetaBackgroundService>());

//Coseguro
builder.Services
    .AddSingleton<ICoseguroService, CoseguroService>()
    .AddSingleton<CoseguroBackgroundService>()
    .AddHostedService(provider => provider.GetRequiredService<CoseguroBackgroundService>());
//CambiaTipoPrestacion
builder.Services
    .AddSingleton<ICambiaTipoPrestacionService, CambiaTipoPrestacionService>()
    .AddSingleton<CambiaTipoPrestacionBackgroundService>()
    .AddHostedService(provider => provider.GetRequiredService<CambiaTipoPrestacionBackgroundService>());

builder.Services.AddControllers();

// configure the Logger
builder.Services.AddLogging(loggingBuilder => {
    loggingBuilder.AddFile(configuration.GetSection("Logging"));
});

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services
    .AddEndpointsApiExplorer()
    .AddSwaggerGen(x => x.IncludeXmlComments(Path.Combine(AppContext.BaseDirectory, "Acudir.Services.WorkersContainer.xml")))
    .AddHealthChecks();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment() || app.Environment.IsEnvironment("QA") || app.Environment.IsEnvironment("Staging"))
{
    app.UseSwagger();
    app.UseSwaggerUI(x => x.SwaggerEndpoint("/swagger/v1/swagger.json", "Woker Container v1"));
}

app
    .UseHttpsRedirection()
    .UseAuthorization();

app.MapHealthChecks("/health");

app.MapControllers();

app.Run();